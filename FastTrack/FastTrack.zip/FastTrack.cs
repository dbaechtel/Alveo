﻿/*
 * * LEGAL DISCLAIMER *

The currency markets can do ANYTHING at ANY TIME.
No one can guarantee or forecast how these results will perform or behave in future markets.
Anyone who uses this product or this information is responsible for deciding If, Where, When and How this product and information are used.
Anyone who uses this product or this information is responsible and liable for any outcomes that might result from the use of this product or this information.
There is no warranty or guarantee provided or implied for this product or this information for any purpose.
 */

#region usingDirectives
// DLL Libararies to use
// **Make sure tha these Libraries have been added to the Project References in Solution
using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.ComponentModel;
using Alveo.Interfaces.UserCode;
using Alveo.Common.Classes;
using Alveo.Common.Enums;
#endregion

// The EA uses an HEMA indicator to determine trade Entry points.

namespace Alveo.UserCode
{
    [Serializable]
    [Description("")]
    public class FastTrack : ExpertAdvisorBase   // **Expert Advisor Class name must be the same as the filename
    {
        public enum PriceTypes
        {
            PRICE_CLOSE = 0,
            PRICE_OPEN = 1,
            PRICE_HIGH = 2,
            PRICE_LOW = 3,
            PRICE_MEDIAN = 4,
            PRICE_TYPICAL = 5,
            PRICE_WEIGHTED = 6,
            PRICE_OHLC = 7
        }

        #region Properties          // ** Add Alveo EA User Settings Declared here

        [Category("LotSize")]
        [Description("Perecnt of Balance Lot Size in %. [ex: 100]")]
        public int pctLotSize { get; set; }

        [Category("LotSize")]
        [Description("Limit to maximum lot size. In Std lots. [25]")]
        public double maxLotLimit { get; set; }   // Limit to maximum lot size

        [Category("StopLoss")]
        [Description("Trailing StopLoss Enable boolean. [ex: true=on]")]
        public bool TrailingSL { get; set; }

        [Category("SMA")]
        [Description("SMA Period in Bars [ex: 50]")]
        public int MA_period { get; set; }

        [Category("Stochastic")]
        [Description("K_period in Bars [ex: 15]")]
        public int K_period { get; set; }

        [Category("Settings")]
        [Description("D_period in Bars [ex: 3]")]
        public int D_period { get; set; }

        [Category("Settings")]
        [Description("Threshold in 1e-6 [ex: 20]")]
        public int Threshold { get; set; }

        [Description("Price type on witch Stochastic will be calculated")]
        [Category("PriceType")]
        [DisplayName("Price Type")]
        public PriceTypes PriceType { get; set; }
        #endregion

        #region EA variables    // ** Declare EA variables here
        FastTrack ea;                        // a reference to  the EA class itself for use by other classes
        string version = "2.0";
        datetime datetime0 = 0;             // minimum datetime
        const string pair = "EUR/USD";      // default curency
        bool startSession;                  // start of session flag
        bool sessionEnded;
        int countBars;
        public bool simulate;               // simulation mode flag
        public bool optimize;               // optimization mode flag
        public string simSymbol;            // symbol for simulation
        public double simAccountBalance;           // Account Balance for Simulation
        public DateTime simTime;            // UTC Time for simulation
        public DateTime simLocalTime;       // Local Time for simulation
        internal TimeFrame simTimeframe;    // chart timeframe for simulation
        public int simBars;                 // number of chart bars for simulation
        Random rnd = new Random(2874);        // random selector for Sl or TP simulation selector
        public string strategy;             // strategy name;
        string symbol;                      // chart symbol
        double pipPos;                      // Pip position
        double point;                       // Point multipler
        int ticketNum;                      // order ticketNum
        internal double curPrice;           // current Price
        int accountNumber;                  // account number
        DateTime curTime;                   // current UTC Time
        internal BarData curBar;            // current Bar
        internal EA_State s;                // EA State Class object
        internal bool riskLimitReached;     // riskLimitReached
        internal bool tradingclosed;        // tradingclosed
        internal bool maintPeriod;          // maintenance period
        internal bool paused;               // trading Paused, no new trades
        internal Object TLock;              // Lock for TradeLog file access
        internal double accountBalance;     // account balance
        internal double riskLimit;          // in Pips,  i.e. 1.8% of AccountBallance for 1 Standard lot
        string magicStr;
        TimeFrame timeFrame;
        bool firstLine;
        internal DateTime OldTime, OldTime2, OldTime3, nextDay;
        double TickValue;
        int curBars;
        int total;
        internal string dataFileDir;       //directory for data files
        System.IO.StreamWriter tradeLogFile;             // StreamWriter for tradeLogFile
        int StopLoss;

        SMAobj sma;                         // Indicator objects
        HSTO sto;
        Swings swings;

        TimeSpan fridayPause = new TimeSpan(12 + 2, 00, 00);         // Local time
        TimeSpan fridayclose = new TimeSpan(12 + 4, 50, 00);         // Local time
        TimeSpan dailyMaintStart = new TimeSpan(12 + 4, 50, 00);     // Local time
        TimeSpan dailyMaintEnd = new TimeSpan(12 + 5, 15, 00);       // Local time
        TimeSpan sundayOpen = new TimeSpan(22, 00, 00);              // UTC time

        int sessionSundayOpen = 0;     // 00:00
        int sessionSundayClose = 86400; // 24:00
        int sessionMondayThursdayOpen = 0;     // 00:00
        int sessionMondayThursdayClose = 86400; // 24:00
        int sessionFridayOpen = 0;     // 00:00
        int sessionFridayClose = 86400; // 24:00
        bool sessionIgnoreSunday = true;
        bool sessionCloseAtSessionClose = true;
        bool sessionCloseAtFridayClose = true;
        public bool TPflag;
        public bool SLflag;
        #endregion

        #region EA constructors      // **Declare EA Constructors and Initialize Class variables
        public FastTrack()      // Class constuctor, called by Alveo
        {
            ea = this;
            simulate = false;
            optimize = false;
            InitEA();
        }

        public FastTrack(bool optimizing, DateTime time, string path)  // constructor called by simulation
        {
            ea = this;
            simulate = true;
            optimize = optimizing;
            simTime = time;
            dataFileDir = path;
            InitEA();
        }

        public void InitEA()  // ** Initiatization of EA variables on creation
        {
            // Initializa EA variables
            copyright = "(C)2018 Entity3 LLC. all rights reserved";
            link = "";
            strategy = this.Name;
            simSymbol = pair;
            simBars = 0;
            symbol = simSymbol;
            simTimeframe = TimeFrame.M15;
            ticketNum = 0;
            countBars = 0;

            // ** Default User Setting values
            MA_period = 35;
            K_period = 15;
            D_period = 4;
            Threshold = 20;
            PriceType = PriceTypes.PRICE_OHLC;
            pctLotSize = 1;                // percent
            maxLotLimit = 0.01;
            TrailingSL = true;

            curPrice = double.MinValue;
            curTime = GetCurTime();
            curBar = null;
            curBars = 0;
            riskLimit = 1.8;                // in Pips,  i.e. 1.8% of AccountBallance for 1 Standard lot
            riskLimitReached = false;
            simAccountBalance = 100000;
            accountNumber = 0;
            riskLimitReached = false;
            tradingclosed = false;
            maintPeriod = false;
            paused = false;
            s = new EA_State();         // create EA State object
            StopLoss = 0;
            sessionEnded = true;
            firstLine = true;
        }
        #endregion

        #region Alveo software Entry points
        //external interface for Simulator
        internal int doInit()
        {
            return this.Init();
        }

        //+------------------------------------------------------------------+"
        //| EA initialization function                                       |"
        //|                                                                  |"
        //| called by Alveo to init EA when refreshed ore restarted          |"
        //+------------------------------------------------------------------+"

        // ** Initialize EA variable when the EA is restarted by Alveo
        protected override int Init()
        {
            try     // EXception Handling in case something goes wrong
            {
                LogPrint("Init: started.");
                timeFrame = GetTimeframe();
                curTime = GetCurTime();
                countBars = 0;
                sessionEnded = true;  // start new session
                paused = false;
                symbol = GetSymbol().Trim();
                var digits = GetDigits();
                pipPos = Math.Pow(10, digits - 1);
                point = 1 / pipPos / 10;
                TickValue = GetTickValue();
                var tf = ea.timeFrame;
                var tfStr = (tf != TimeFrame.Unknown) ? tf.ToString() : "S10";
                dataFileDir = "C:\\temp\\" + strategy + " " + symbol.Replace('/', '-') + " " + tfStr + "\\";       //directory for data files
                magicStr = strategy + "," + symbol.Replace("/", "") + ", " + tfStr;
                if (s == null)
                    s = new EA_State();
                s.ClearState();
                OldTime = ea.UtcTimeNow();
                OldTime2 = OldTime;
                OldTime3 = ea.UtcTimeNow();
                nextDay = new DateTime(
                      OldTime3.Year,
                      OldTime3.Month,
                      OldTime3.Day,
                      0, 0, 0, 0) + TimeSpan.FromHours(24);
                if (s.firstRun)     // initialization on firstRun
                {
                    if (!optimize)
                    {
                        if (!System.IO.Directory.Exists("C:\\temp"))
                            System.IO.Directory.CreateDirectory("C:\\temp");
                        if (!System.IO.Directory.Exists(dataFileDir))
                            System.IO.Directory.CreateDirectory(dataFileDir);
                    }
                    sessionEnded = true;
                    s.firstRun = false;
                }
                if (optimize)
                    LoadBestParameters();  // load trading parameters from file
                sma = new SMAobj(ref ea, MA_period, 30);
                sto = new HSTO(ref ea, K_period, D_period, Threshold);
                swings = new Swings(3 * K_period);
                accountNumber = GetAccountNumber();
                s.startingBalance = GetAccountBalance();
                s.closedOrders.Clear();
                if (!optimize)
                    LogPrint(" Init: Initialization successful. Verion=" + version);
            }
            catch (Exception e)
            {
                LogPrint("Init:" + e.Message);
                LogPrint(e.StackTrace);
            }
            return 0;
        }

        //+------------------------------------------------------------------+"
        //| expert deinitialization function                                 |"
        //|                                                                  |"
        //| called by Alveo to unitialize EA before termination.             |"
        //+------------------------------------------------------------------+"
        protected override int Deinit()
        {
            if (!optimize)
                LogPrint(strategy + " Deinit.");
            // ** Do any cleanup required before EA terminates
            return 0;
        }

        // eternal interface for Simulator
        internal int doStart()
        {
            return this.Start();
        }

        //+------------------------------------------------------------------+"
        //| expert start function                                            |"
        //|                                                                  |"
        //| called by Alveo for every new bar on chart                       |"
        //| and when the Bid or Ask price change (several times per second.  |"
        //+------------------------------------------------------------------+"
        protected override int Start()
        {
            try
            {
                if (!CheckParameters())  // make sure that all User Settings are valid
                {
                    if (!optimize)
                        LogPrint("User Settings are invalid !!");
                    return 0;
                }
                if (!simulate && Chart == null)     // must have Chart
                    return 0;
                curTime = GetCurTime();
                curBar = GetCurBar();
                symbol = GetSymbol();
                var nBars = GetBars();      // When a new Bar closes
                if (nBars <= curBars)       // no new Bar
                    return 0;
                curBars = nBars;
                var oos = IsOutOfSession();
                if (curBar == null)
                {
                    LogPrint("Start: No chart Bars are available!! ");
                    return 0;
                }
                s.dI = curBar;
                curPrice = s.dI.close;
                accountBalance = GetAccountBalance();
                riskLimit = 1.8 * accountBalance / 100 / 10; // 1.8 percent risk limit in Pips for 1 Standard lot
                if (DetectChanged(ref s.OKtoTrade, CheckOKToTrade()))
                {
                    if (!optimize)
                        LogPrint(" OKtoTrade=" + s.OKtoTrade.ToString());
                }
                if (!s.OKtoTrade && sessionEnded)
                {
                    startSession = true;
                    sessionEnded = false;
                    return 0; // EA cannot trade at this time
                }
                // else OKtoTrade
                if (startSession)
                    countBars = 0;
                else
                    countBars++;
                Monitor();                  // Monitor all orders
                Strategy();                 // execute trading Strategy
                total = GetTotalOrders();
                startSession = false;       // start of session is complete
            }
            catch (Exception e)  // in case something goes horribly wrong
            {
                LogPrint(" Start: Exception: " + e.Message);
                LogPrint("Exception: " + e.StackTrace);
                throw e;
            }
            return 0;
        }
        #endregion

        #region Encapsulated Data Classes
        // encapsulated EA State Class
        // holds EA State data
        internal class EA_State
        {
            internal bool firstRun;
            internal bool isConnected;
            internal bool Stopped;
            internal bool isTradeAllowed;
            internal bool OKtoTrade;
            internal Statistics stats;
            internal BarData dI;
            internal int targetDir;
            internal double startingBalance;
            internal int ordersThisHour;
            internal int ordersThisDay;
            private Object thisLock;
            internal Dictionary<long, Order> buyOpenOrders = null;
            internal Dictionary<long, Order> sellOpenOrders = null;
            internal Dictionary<long, Order> closedOrders = null;

            /// <summary>
            /// DENA3_State Class object constructor
            /// </summary>
            public EA_State()
            {
                firstRun = true;
                isConnected = true;
                Stopped = false;
                isTradeAllowed = false;
                OKtoTrade = true;
                stats = new Statistics(0);
                thisLock = new Object();
                buyOpenOrders = null;
                sellOpenOrders = null;
                closedOrders = null;
            }

            /// <summary>
            /// DENA3_State initialization
            /// </summary>
            internal void ClearState()
            {
                isConnected = true;
                Stopped = false;
                isTradeAllowed = false;
                stats = new Statistics(0);
                dI = null;
                targetDir = 0;
                startingBalance = double.MinValue;
                ordersThisHour = 0;
                ordersThisDay = 0;
                buyOpenOrders = new Dictionary<long, Order>();
                sellOpenOrders = new Dictionary<long, Order>();
                closedOrders = new Dictionary<long, Order>();
            }

            /// <summary>
            /// Save DENA3_State to restore file
            /// <param name="restore">ref to System.IO.StreamWriter</param>
            /// </summary>
            public struct Statistics
            {
                internal double profitLoss;
                internal double maxProfit;
                internal double maxLoss;
                internal double maxDrawdown;
                internal double maxDailyDrawdown;
                internal double largestDailyDrawdown;
                internal bool exceededDailyDrawdown;
                internal int numContracts;
                internal int numWins;
                internal int numLoss;
                internal double avgWin;
                internal double avgLoss;
                internal double winRate;
                internal double expectancy;
                internal int numOpen;
                internal int numDays;
                internal int numHours;
                internal int numTrades;
                internal int numOrders;
                internal int orderExits;
                internal int computeStats;
                internal double sumPips;
                internal int sumWins;
                internal int sumLoss;
                internal double avgWin2;
                internal double avgLoss2;
                internal double avgWinBars;
                internal double avgLossBars;
                internal int numEntries;
                internal int numJISO;

                /// <summary>
                /// Initialize Trading Statistics
                /// </summary>
                internal Statistics(int x)
                {
                    profitLoss = 0;
                    maxProfit = 0;
                    maxLoss = 0;
                    maxDrawdown = 0;
                    maxDailyDrawdown = 0;
                    largestDailyDrawdown = 0;
                    exceededDailyDrawdown = false;
                    numContracts = 0;
                    numWins = 0;
                    numLoss = 0;
                    avgWin = 0;
                    avgLoss = 0;
                    winRate = 0;
                    expectancy = 0;
                    numOpen = 0;
                    numDays = 0;
                    numHours = 0;
                    numTrades = 0;
                    numOrders = 0;
                    orderExits = 0;
                    computeStats = 0;
                    sumPips = 0;
                    sumWins = 0;
                    sumLoss = 0;
                    avgWin2 = 0;
                    avgLoss2 = 0;
                    avgWinBars = 0;
                    avgLossBars = 0;
                    numEntries = 0;
                    numJISO = 0;
                }
            }
        }

        // encapsulated BarData Class
        // holds data needed for each chart Bar
        public class BarData
        {
            internal string symbol;
            internal Bar bar;
            internal DateTime BarTime;
            internal double open;
            internal double high;
            internal double low;
            internal double close;
            internal long volume;
            internal double bid;
            internal double ask;
            internal bool startOfSession;
            internal bool buySide;
            internal double typical;
            internal double change;
            internal double pctChange;
            internal double HEMA;
            internal double smoothedK;
            internal double smoothedD;
            internal double slowedD;
            internal double spread;
            internal DayOfWeek wd;
            internal TimeSpan tod;

            /// <summary>
            /// EA BarData Item Class
            /// </summary>
            public BarData()
            {
                BarData_Init();
            }

            /// <summary>
            /// BarData object constructor with Bar data
            /// </summary>
            public BarData(Bar ibar, double iBid = 0, double iAsk = 0)
            {
                BarData_Init();
                bar = ibar;
                BarTime = ibar.BarTime;
                open = (double)ibar.Open;
                high = (double)ibar.High;
                low = (double)ibar.Low;
                close = (double)ibar.Close;
                volume = ibar.Volume;
                wd = BarTime.DayOfWeek;
                tod = BarTime.TimeOfDay;
                bid = iBid;
                ask = iAsk;
                if (bid * ask > 0)  // if bid and ask are both > 0
                    spread = ask - bid;
            }

            /// <summary>
            /// BarData initialization
            /// </summary>
            internal void BarData_Init()
            {
                symbol = "";
                BarTime = DateTime.MinValue;
                high = 0;
                low = 0;
                close = 0;
                volume = -1;
                bid = 0;
                ask = 0;
                startOfSession = true;
                buySide = true;
                typical = 0;
                change = 0;
                HEMA = 0;
                smoothedK = 50;
                smoothedD = 50;
                slowedD = 50;
                pctChange = 0;
                spread = 0;
                wd = BarTime.DayOfWeek;
                tod = BarTime.TimeOfDay;
            }
        }
        #endregion

        #region Strategy
        // Monitor for Closed orders
        // Monitor for Start of Day and start of Hour
        // Simulate market actions
        // **Add evants and actions that you want to monitor or to simulate
        public void Monitor()
        {
            int total = GetTotalOrders();
            // count trading numDays
            if (OldTime3 > curTime || curTime >= nextDay)
            {
                if (!optimize)
                    LogPrint(" Start of Day. ");
                s.stats.numDays++;
                s.ordersThisDay = 0;
                OldTime3 = curTime;
                nextDay = new DateTime(
                  OldTime3.Year,
                  OldTime3.Month,
                  OldTime3.Day,
                  0, 0, 0, 0) + TimeSpan.FromHours(24);
                var pctDd = 100 * s.stats.maxDailyDrawdown / accountBalance;  // update statistics
                if (s.stats.largestDailyDrawdown > pctDd)
                    s.stats.largestDailyDrawdown = pctDd;
                s.startingBalance = accountBalance;
                s.stats.maxDailyDrawdown = 0;
                s.stats.exceededDailyDrawdown = false;
                riskLimitReached = false;
            }
            // count trading numHours
            if (OldTime2 > curTime || curTime.Subtract(OldTime2) >= TimeSpan.FromHours(1))
            {
                if (!optimize)
                    LogPrint(" New Hour. ");
                s.stats.numHours++;
                OldTime2 = curTime;
                s.ordersThisHour = 0;
                if (!simulate)
                    LogPrint(" Monitor still running. " + curTime.ToLongTimeString());
            }
            var drawdown = accountBalance - s.startingBalance;
            if (drawdown < s.stats.maxDailyDrawdown)
            {
                s.stats.maxDailyDrawdown = drawdown;
            }
            var pctDrawdown = 100 * s.stats.maxDailyDrawdown / s.startingBalance;
            if (Math.Abs(pctDrawdown) > 4.75)
            {
                if (!optimize)
                    LogPrint(" CreateOrder: exceededDailyDrawdown " + pctDrawdown.ToString("F2"));
                s.stats.exceededDailyDrawdown = true;
            }
            if (s.stats.exceededDailyDrawdown)
            {
                closeAllTrades(reason: 3);
                return; // wait until next day to trade
            }
            RemoveClosedOrders();
            var highest = GetCurBar().high;
            var lowest = GetCurBar().low;
            if (simulate)
            {
                // check buyOpenOrders for TP or SL
                if (s.buyOpenOrders.Count > 0)
                {
                    foreach (var order in s.buyOpenOrders.Values)
                    {
                        double tp = (double)order.TakeProfit;
                        double sl = (double)order.StopLoss;

                        TPflag = (tp > 0 && highest >= tp);
                        SLflag = (sl > 0 && lowest <= sl);
                        if (TPflag && SLflag)  // randomly reset one flag, if both are set
                        {
                            var nxtRnd = rnd.Next(1, 10);
                            var selectTP = (nxtRnd > 5);
                            if (selectTP)
                                SLflag = false;
                            else
                                TPflag = false;
                        }
                        if (TPflag)
                        {
                            if (!optimize)
                            {
                                LogPrint("**Buy Order TakeProfit. Ticket=" + order.Id);
                            }
                            ExitOpenTrade(reason: 1, order: order, price: tp + 1 * point);
                            //s.closedOrders.Add(order.Id, order);
                            if (simulate)
                                order.CloseType = CloseType.TakeProfit;
                        }
                        else if (SLflag)
                        {
                            if (!optimize)
                            {
                                LogPrint("!!Buy Order StopLoss. Ticket=" + order.Id);
                                LogPrint("sl=" + sl + " lowest=" + lowest);
                            }
                            ExitOpenTrade(reason: 2, order: order, price: sl - 1 * point);
                            //s.closedOrders.Add(order.Id, order);
                            if (simulate)
                                order.CloseType = CloseType.StopLoss;
                        }
                    }
                }

                // check sellOpenOrders for TP or SL
                if (s.sellOpenOrders.Count > 0)
                {
                    foreach (var order in s.sellOpenOrders.Values)
                    {
                        double tp = (double)order.TakeProfit;
                        double sl = (double)order.StopLoss;
                        TPflag = (tp > 0 && lowest <= tp);
                        SLflag = (sl > 0 && highest >= sl);
                        if (TPflag && SLflag)  // randomly reset one flag
                        {
                            var selectTP = (rnd.Next(1, 10) > 5);
                            if (selectTP)
                                SLflag = false;
                            else
                                TPflag = false;
                        }
                        if (TPflag)
                        {
                            if (!optimize)
                                LogPrint("**Sell Order TakeProfit. Ticket=" + order.Id);
                            ExitOpenTrade(reason: 3, order: order, price: tp - 1 * point);
                            //s.closedOrders.Add(order.Id, order);
                            if (simulate)
                                order.CloseType = CloseType.TakeProfit;
                        }
                        if (SLflag)
                        {
                            if (!optimize)
                            {
                                LogPrint("!!Sell Order StopLoss. Ticket=" + order.Id);
                                LogPrint("sl=" + sl + " highest=" + highest);
                            }
                            ExitOpenTrade(reason: 4, order: order, price: sl + 1 * point);
                            //s.closedOrders.Add(order.Id, order);
                            if (simulate)
                                order.CloseType = CloseType.StopLoss;
                        }
                    }
                }
                RemoveClosedOrders();
            }

            Dictionary<long, Order> openOrders = s.buyOpenOrders;
            openOrders = openOrders.Concat(s.sellOpenOrders).ToDictionary(x => x.Key, x => x.Value);
            // check closed recentOrders for Trailing StopLoss
            int count = openOrders.Count;
            if (count > 0)
            {
                var orderIDs = openOrders.Keys.ToList();
                if (!optimize && count > 1)
                {
                    LogPrint("#2 recentOrders.Count=" + count);
                    LogPrint("orderIDs.Count=" + orderIDs.Count);
                }
                foreach (int ticketID in orderIDs)
                {
                    Order order;
                    if (!openOrders.TryGetValue(ticketID, out order))
                    {
                        if (!optimize)
                            LogPrint("recentOrders not found. ticket=" + ticketID);
                        continue;
                    }
                    var tm = GetOrderCloseTime(ticketID);
                    if (!optimize && count > 1)
                    {
                        LogPrint("ticketID=" + ticketID + ".tm=" + tm.ToString());
                        LogPrint("orderIDs.Count=" + orderIDs.Count);
                    }

                    if (tm.DateTime.Year > 1980) // Closed
                    {
                        order.ClosePrice = (decimal)GetOrderClosePrice(ticketID);
                        if (!optimize)
                            LogPrint("Monitor: Order closed. ticket=" + ticketID + " ClosePrice=" + order.ClosePrice);
                        if (order.CloseType == CloseType.Unknown)
                        {
                            order.CloseType = CloseType.Market;
                            if (order.Side == TradeSide.Buy)
                            {
                                if ((double)order.ClosePrice >= (double)order.TakeProfit - 10 * point)
                                    order.CloseType = CloseType.TakeProfit;
                                else if ((double)order.ClosePrice <= (double)order.StopLoss + 10 * point)
                                    order.CloseType = CloseType.StopLoss;
                            }
                            else if (order.Side == TradeSide.Sell)
                            {
                                if ((double)order.ClosePrice <= (double)order.TakeProfit + 10 * point)
                                    order.CloseType = CloseType.TakeProfit;
                                else if ((double)order.ClosePrice >= (double)order.StopLoss - 10 * point)
                                    order.CloseType = CloseType.StopLoss;
                            }
                        }
                        if (!optimize)
                            LogPrint("Monitor: Order CloseType=" + order.CloseType.ToString()
                                + " ClosePrice=" + order.ClosePrice
                                + " TakeProfit=" + order.TakeProfit
                                + " StopLoss=" + order.StopLoss
                                );
                        if (!simulate && order.Quantity > 0)
                        {
                            if (!optimize)
                                LogPrint("Monitor: ticket=" + ticketID + " CloseType=" + order.CloseType.ToString());
                            TPflag = (order.CloseType == CloseType.TakeProfit);
                            SLflag = (order.CloseType == CloseType.StopLoss);
                        }
                        TradeClosed(order);
                        if (!optimize)
                        {
                            string msg = "";
                            if (TPflag)
                                msg += " TPflag=" + TPflag;
                            if (SLflag)
                                msg += " SLflag=" + SLflag;
                            LogPrint("Monitor: Closed order. ID=" + order.Id
                                + " Side=" + ((order.Side == OP_BUY) ? "Buy" : "Sell")
                                + msg
                                + " CloseTime=" + tm.ToString());
                        }
                    }
                    else // !closed
                    {
                        // update Trailing Stoploss
                        if (TrailingSL && (double)order.Quantity > 0)
                        {
                            if (!paused && s.OKtoTrade)
                                CheckOrderModify((int)order.Id, StopLoss, ref order);
                        }
                    }
                }
            }
            RemoveClosedOrders();
        }

        // Trade Strategy
        // ** Add you Trade Strategy here
        internal void Strategy()
        {
            try
            {
                if (startSession)  // clear previos data;
                {
                    if (!optimize)
                    {
                        var msg = (" startSession=" + startSession);
                        LogPrint(msg);
                    }
                    closeAllTrades(reason: 1);
                }
                CheckPaused();      // do not trade if Friday afternoon
                if (paused || !s.OKtoTrade || s.ordersThisHour > 25 || s.ordersThisDay > 35)
                {
                    return;
                }
                total = GetTotalOrders();
                if (total == 0)
                {
                    s.targetDir = 0;
                    if (!paused && !s.stats.exceededDailyDrawdown && countBars > 5)
                    {
                        sma.Calc(s.dI);
                        sto.Calc(s.dI.bar);
                        swings.Calc(sma.thePrice);
                        if (sma.isRrising && sto.pctDrising && sto.smoothedD < 50 && sto.prevDtrend <= 0 && sto.Dtrend > 0)
                        {
                            s.targetDir = 1;                // Open Market trade, Side = Buy
                            double slPrice = Math.Min(swings.swingLow, sma.value);
                            StopLoss = (int)Math.Truncate(Math.Max((GetAsk() - slPrice), 0) / GetPoints()) + 2;
                            var ticket = CreateOrder(lotsize: 0.01, stoploss: StopLoss, takeprofit: 2 * StopLoss);
                        }
                        else if (sma.isFalling && sto.pctDfalling && sto.smoothedD > 50 && sto.prevDtrend >= 0 && sto.Dtrend < 0)
                        {
                            s.targetDir = -1;               // Open Market trade, Side = Sell
                            double slPrice = Math.Max(swings.swingHigh, sma.value);
                            StopLoss = (int)Math.Truncate(Math.Max((slPrice - GetBid()), 0) / GetPoints()) + 2;
                            var ticket = CreateOrder(lotsize: 0.01, stoploss: StopLoss, takeprofit: 2 * StopLoss);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                LogPrint(" Exception: " + e.Message);
                LogPrint(" Exception: " + e.StackTrace);
            }
        }
        #endregion

        #region Utillity Routimes
        internal void CheckPaused()
        {
            var LT = GetLocalCurTime();
            var prevPaused = paused;
            paused = ((LT.DayOfWeek == System.DayOfWeek.Friday && LT.TimeOfDay >= fridayPause));
            if (paused)
            {
                if (!optimize && !prevPaused)
                    LogPrint(" Trading Paused. Friday afternoon." + LT.ToString());
            }
            if (!paused)
            {
                if (!optimize && prevPaused)
                    LogPrint(" Trading Resumed. local time=" + LT.ToString());
            }
        }

        internal void CheckOrderModify(int ticket, double SLlimit, ref Order order)
        {
            ModifyOrder(ticket, SLlimit, ref order);
        }

        internal void CheckOrderClose(bool closePos)
        {
            total = GetTotalOrders();
            if (total > 0)
            {
                if (closePos)
                {
                    closeAllTrades(reason: 2);
                    RemoveClosedOrders();
                    s.targetDir = 0;
                    total = GetTotalOrders();
                }
            }
        }

        internal void RemoveClosedOrders()  // Remove Closed ordrs from Open Orders Lists
        {
            if (s.closedOrders.Count > 0)
            {
                foreach (var iD in s.closedOrders.Keys)
                {
                    if (s.buyOpenOrders.Count > 0)
                        s.buyOpenOrders.Remove(iD);
                    if (s.sellOpenOrders.Count > 0)
                        s.sellOpenOrders.Remove(iD);
                }
                s.closedOrders.Clear();
            }
        }

        internal bool CheckParameters()
        {
            return true;
        }

        // external interface for Simulation Statistics
        internal EA_State.Statistics GetStats()
        {
            EA_State.Statistics stats = s.stats;
            return stats;
        }

        internal struct MqlDateTime
        {
            internal int year;           // Year
            internal int mon;            // Month
            internal int day;            // Day
            internal int hour;           // Hour
            internal int min;            // Minutes
            internal int sec;            // Seconds
            internal int day_of_week;    // Day of week (0-Sunday, 1-Monday, ... ,6-Saturday)
            internal int day_of_year;    // Day number of the year (January 1st is assigned the number value of zero)
        };

        internal void TimeToStruct(
            DateTime dt,            // date and time
            ref MqlDateTime dt_struct      // structure for the adoption of values
        )
        {
            dt_struct.year = dt.Year;           // Year
            dt_struct.mon = dt.Month;            // Month
            dt_struct.day = dt.Day;            // Day
            dt_struct.hour = dt.Hour;           // Hour
            dt_struct.min = dt.Minute;            // Minutes
            dt_struct.sec = dt.Second;            // Seconds
            dt_struct.day_of_week = (int)dt.DayOfWeek;    // Day of week (0-Sunday, 1-Monday, ... ,6-Saturday)
            dt_struct.day_of_year = dt.DayOfYear;    // Day number of the year (January 1st is assigned the number value of zero)
        }

        int PeriodSeconds(TimeFrame period = TimeFrame.Unknown)     // chart period
        {
            int seconds = (period != TimeFrame.Unknown) ? (int)period * 60 : 1;
            return seconds;
        }

        bool IsOutOfSession()
        {
            MqlDateTime time0 = new MqlDateTime();
            var curTime = (datetime)GetCurTime();
            TimeToStruct(curTime, ref time0);
            int weekDay = time0.day_of_week;
            long timeFromMidnight = curTime % 86400;
            int periodLength = PeriodSeconds(timeFrame);
            bool skipTrade = false;

            if (weekDay == 0)
            {
                if (sessionIgnoreSunday) return true;
                int lastBarFix = sessionCloseAtSessionClose ? periodLength : 0;
                skipTrade = timeFromMidnight < sessionSundayOpen || timeFromMidnight + lastBarFix > sessionSundayClose;
            }
            else if (weekDay < 5)
            {
                int lastBarFix = sessionCloseAtSessionClose ? periodLength : 0;
                skipTrade = timeFromMidnight < sessionMondayThursdayOpen || timeFromMidnight + lastBarFix > sessionMondayThursdayClose;
            }
            else
            {
                int lastBarFix = sessionCloseAtFridayClose || sessionCloseAtSessionClose ? periodLength : 0;
                skipTrade = timeFromMidnight < sessionFridayOpen || timeFromMidnight + lastBarFix > sessionFridayClose;
            }
            return (skipTrade);
        }


        // for optimizing, load trading parameters from file
        void LoadBestParameters()
        {
            try
            {
                string path;
                string parseErr = "Exception LoadBestParameters: parse error at ";
                string paramFilename = "ParamSet" + symbol.Replace("/", "") + ((simulate) ? "0" : "1") + ".csv";
                path = dataFileDir + paramFilename;
                if (!System.IO.File.Exists(path))
                {
                    if (!optimize)
                        LogPrint("EA: File " + path + " does not exist !!");
                    throw new Exception("Exception: File " + path + " does not exist !!");
                }
                System.IO.StreamReader best = new System.IO.StreamReader(path);
                if (!optimize)
                    LogPrint("EA: Reading File " + path);
                var line = best.ReadLine();
                line = best.ReadLine();
                char[] delimiterChars = { ',', '\t' };
                string[] vals = line.Split(delimiterChars);
                if (vals.Count() != 18)
                    throw new Exception("Exception: File " + path + " improper format !!");
                // var digits = GetDigits();
                strategy = vals[0];
                int X;
                if (!int.TryParse(vals[4], out X))
                    throw new Exception(parseErr + "MA_period !!");
                MA_period = X;
                if (!int.TryParse(vals[5], out X))
                    throw new Exception(parseErr + "K_period !!");
                K_period = X;
                if (!int.TryParse(vals[6], out X))
                    throw new Exception(parseErr + "D_period !!");
                D_period = X;
                if (!int.TryParse(vals[7], out X))
                    throw new Exception(parseErr + "Threshold !!");
                Threshold = X;
                best.Close();

            }
            catch (Exception e)
            {
                LogPrint("Exception: " + e.Message);
                LogPrint("Exception: " + e.StackTrace);
            }
            return;
        }

        void JournalOnExit(int reason, Order order, double bclose, BarData dI,
        double t2 = 0, double t5 = 0, double dProfit = 0, double stoploss = 0)
        {
            if (optimize || simulate || order == null || true)
                return;
            var side = order.Side;

            double openPrice = (double)order.OpenPrice;
            switch (reason)
            {
                case 1: // take profit on Buy order
                    LogPrint("ExitOpenTrade: reason = take profit on Buy order.");
                    LogPrint(" order=" + order.Id + " openPrice=" + openPrice.ToString("F5")
                        + " close=" + bclose.ToString("F5") + " dProfit=" + dProfit.ToString("F5")
                    );
                    break;
                case 2: // stoploss on Buy order
                    LogPrint("ExitOpenTrade: reason = stoploss on Buy order.");
                    LogPrint(" order=" + order.Id + " openPrice=" + openPrice.ToString("F5")
                        + " close=" + bclose.ToString("F5") + " dProfit=" + dProfit.ToString("F5"));
                    break;
                case 3: // take profit on Sell order
                    LogPrint("ExitOpenTrade: reason = take profit on Sell order.");
                    LogPrint(" order=" + order.Id + " openPrice=" + openPrice.ToString("F5")
                        + " close=" + bclose.ToString("F5") + " dProfit=" + dProfit.ToString("F5")
                    );
                    break;
                case 4: // stoploss on Sell order
                    LogPrint("ExitOpenTrade: reason = stoploss on Sell order.");
                    LogPrint(" order=" + order.Id + " openPrice=" + openPrice.ToString("F5")
                        + " close=" + bclose.ToString("F5") + " dProfit=" + dProfit.ToString("F5"));
                    break;
                case 5: // closeAllTrades: tradingclosed || riskLimitReached
                    LogPrint("closeAllTrades: reason = tradingclosed || riskLimitReached close=" + bclose.ToString());
                    LogPrint(" dI.Date=" + dI.BarTime.ToShortDateString() + " " + dI.BarTime.ToLongTimeString() + " dProfit=" + dProfit.ToString("F5"));
                    LogPrint(" tradingclosed=" + tradingclosed + " riskLimitReached=" + riskLimitReached);
                    break;
                case 6: // closeAllTrades: timeToExit
                    LogPrint("closeOpenTrade: reason = timeToExit  close=" + bclose.ToString());
                    LogPrint(" dI.Date=" + dI.BarTime.ToShortDateString() + " " + dI.BarTime.ToLongTimeString() + " dProfit=" + dProfit.ToString("F5"));
                    break;
                case 7: // closeAllTrades: !isTradeAllowed
                    LogPrint("closeOpenTrade: reason = !isTradeAllowed. close=" + bclose.ToString() + " isTradeAllowed=" + s.isTradeAllowed.ToString());
                    LogPrint(" dI.Date=" + dI.BarTime.ToShortDateString() + " " + dI.BarTime.ToLongTimeString() + " dProfit=" + dProfit.ToString("F5"));
                    break;
                case 8: // closeAllTrades: IsEaStopped
                    LogPrint("closeOpenTrade: reason = IsEaStopped.  bclose=" + bclose.ToString() + " IsEaStopped=" + IsEaStopped.ToString());
                    LogPrint(" dI.Date=" + dI.BarTime.ToShortDateString() + " " + dI.BarTime.ToLongTimeString() + " dProfit=" + dProfit.ToString("F5"));
                    break;
                case 9: // IsEaStopped
                    LogPrint("closeOpenTrade: reason = IsEaStopped.  bclose=" + bclose.ToString() + " IsEaStopped=" + IsEaStopped.ToString());
                    LogPrint(" dI.Date=" + dI.BarTime.ToShortDateString() + " " + dI.BarTime.ToLongTimeString() + " dProfit=" + dProfit.ToString("F5"));
                    break;
                case 99:  // closeAllTrades at end of simulation
                    LogPrint("closeOpenTrade: reason = closeAllTrades at end of simulation. close=" + bclose.ToString());
                    LogPrint(" dI.Date=" + dI.BarTime.ToShortDateString() + " " + dI.BarTime.ToLongTimeString() + " dProfit=" + dProfit.ToString("F5"));
                    break;
                default:
                    throw new Exception("Exception: JournalOnclose reason not defined !! ");
                    //break;
            }
        }

        internal void ComputeStats(double dProfit, Order order)
        {
            var qty = (double)order.Quantity;
            if (qty > 0)
            {
                s.stats.profitLoss += dProfit;  // update profitLoss
                simAccountBalance += dProfit;
                accountBalance += dProfit;
                s.stats.numContracts++;  // update numContracts
                if (dProfit >= 0)
                {
                    double count = (double)s.stats.sumWins;
                    s.stats.sumWins++;
                    s.stats.avgWin2 = (s.stats.avgWin2 * count + dProfit) / (double)s.stats.sumWins;
                }
                else // dProfit < 0
                {
                    double count = (double)s.stats.sumLoss;
                    s.stats.sumLoss++;
                    s.stats.avgLoss2 = (s.stats.avgLoss2 * count + dProfit) / (double)s.stats.sumLoss;
                }

                // calculate avgWin, avgLoss, numWins, numLoss, maxProfit, maxLoss, maxDrawdown
                if (dProfit >= 0)
                {
                    s.stats.avgWin = (s.stats.numWins * s.stats.avgWin + Math.Abs(dProfit)) / (s.stats.numWins + 1);
                    s.stats.numWins++;
                }
                else // (dProfit <= 0), Loss
                {
                    s.stats.avgLoss = (s.stats.numLoss * s.stats.avgLoss + Math.Abs(dProfit)) / (s.stats.numLoss + 1);
                    s.stats.numLoss++;
                }
                if (dProfit > s.stats.maxProfit)
                    s.stats.maxProfit = dProfit;
                else if (dProfit < s.stats.maxLoss)
                    s.stats.maxLoss = dProfit;
                if (s.stats.profitLoss < s.stats.maxDrawdown) // compute maxDrawdown
                    s.stats.maxDrawdown = s.stats.profitLoss;
                s.stats.computeStats++; // count num Order statistics computed
            }
        }

        internal void WriteTradeLog(string msg, bool clear = false)
        {
            if (TLock == null)
                TLock = new object();
            lock (TLock)  // exclussive lock, one call access at a time
            {
                // Write msg to TradeLog, Delete and Create new file is clear=true
                var tf = ea.timeFrame;
                var tfStr = (tf != TimeFrame.Unknown) ? tf.ToString() : "S1";
                var account = GetAccountNumber();
                string tradeLogFilename = strategy + " TradeLog_" + symbol.Replace("/", "") + "_" + tfStr + "_" + account + ".csv";
                if (!System.IO.Directory.Exists(dataFileDir))
                    System.IO.Directory.CreateDirectory(dataFileDir);
                if (clear)
                    System.IO.File.Delete(dataFileDir + tradeLogFilename);
                var path = dataFileDir + tradeLogFilename;
                tradeLogFile = new System.IO.StreamWriter(path, append: true);
                FileInfo f = new FileInfo(path);
                var msgWritten = false;
                if (!msgWritten)  // outut without scores
                    tradeLogFile.WriteLine(msg);
                tradeLogFile.Close();
            }
        }

        /// <summary>
        /// LogPrint: print msg to Alveo Log or to Console
        /// </summary>
        /// <returns>void</returns>
        internal void LogPrint(string msg, bool doIt = false)
        {
            if (optimize && !doIt)
                return;
            var tf = ea.timeFrame;
            var tfStr = (tf != TimeFrame.Unknown) ? tf.ToString() : "S1";
            string msg2 = strategy + " [" + symbol + " " + tfStr + "]: " + msg;
            if (!simulate)
                Print(msg2);
            else
                Console.WriteLine(msg2);
        }

        // if value != flag, then change flag = value and return true, otherwise return flase (not changed)
        bool DetectChanged(ref bool flag, bool value)
        {
            bool changed;
            changed = (value != flag);
            if (changed)
            {
                flag = value;
            }
            return changed;
        }
        #endregion

        #region  Alveo simulation routines
        // **routines to call Aveo functions or simulate Alveo functionality in Visual Studio
        // **ALL function cals to Alveo must be encapsulated and simulated to run in Visual Studio
        // emulate Alveo Bars
        internal int GetBars()
        {
            if (simulate)
                return simBars;
            else // Alveo
                return Bars;
        }

        // Get most recent Bar time
        public DateTime GetLocalCurTime()
        {
            if (simulate)
                return simLocalTime;
            else
                return DateTime.Now;
        }

        public DateTime GetCurTime()
        {
            if (simulate)
                return simTime;
            else
                return UtcTimeNow();
        }

        // interface to get current UTC time just in case Alveo has a problem with the function
        DateTime UtcTimeNow()
        {
            DateTime utcNow = DateTime.UtcNow;
            return utcNow;
        }

        // Get Chart currency Symbol
        internal string GetSymbol()
        {
            string symbol = simSymbol;
            if (!simulate)
            {
                symbol = Symbol();
            }
            return symbol;
        }

        // Get Account Balance
        public double GetAccountBalance()
        {
            if (!simulate)
            {
                double accountBalance = AccountBalance();
                return accountBalance;
            }
            return simAccountBalance;  //simulated AccountBalance
        }

        internal bool CheckMaintPeriod()
        {
            bool maint = false;
            var LT = GetLocalCurTime();
            if (LT.TimeOfDay > dailyMaintStart && LT.TimeOfDay < dailyMaintEnd)
                maint = true;
            return maint;
        }

        // checked conditions to determine if it is OK to Trade
        internal bool CheckOKToTrade()
        {
            if (accountBalance > 0 && accountBalance < 50.00)
            {
                if (!optimize)
                    LogPrint(" balance is too low !! AccountBalance = " + accountBalance.ToString("F2"));
                if (!simulate)
                    Sleep(1000);
                sessionEnded = true;
                return false;
            }

            if (DetectChanged(ref riskLimitReached, (s.startingBalance >= 0) ? accountBalance / s.startingBalance < 0.951 : false))
            {
                if (riskLimitReached)
                {
                    if (!optimize)
                    {
                        string msg = (" Start: riskLimitReached, trading prevented. "
                        + " startingBalance =" + s.startingBalance.ToString("F2")
                        + " accountBalance =" + accountBalance.ToString("F2"));
                        LogPrint(msg);
                        LogPrint(msg);
                    }
                    sessionEnded = true;
                }
            }
            if (riskLimitReached)
            {
                closeAllTrades(reason: 5);
                if (!simulate)
                    Sleep(1000); // sleep 1 sec
                sessionEnded = true;
                return false;
            }


            if (DetectChanged(ref tradingclosed, CheckTradingClosed()))
            {
                if (tradingclosed)
                {
                    if (!optimize)
                    {
                        string msg = (" Start: tradingclosed. ");
                        LogPrint(msg);
                        LogPrint(msg);
                    }
                    closeAllTrades(reason: 6);
                    if (!simulate)
                        Sleep(1000); // sleep 1 sec
                    return false;
                }
            }
            if (tradingclosed)
            {
                sessionEnded = true;
                return false;
            }

            if (DetectChanged(ref maintPeriod, CheckMaintPeriod()))
            {
                if (maintPeriod)
                {
                    if (!optimize)
                    {
                        string msg = (" Start: maintPeriod. ");
                        LogPrint(msg);
                    }
                    //CloseAllTrades(reason: 7);
                    if (!simulate)
                        Sleep(1000); // sleep 1 sec
                    return false;
                }
            }
            if (maintPeriod)
                return false;

            if (!simulate)  // Alveo functions
            {
                if (DetectChanged(ref s.isConnected, IsEAConnected()))
                {
                    if (!s.isConnected)
                    {
                        if (!optimize)
                        {
                            string msg = ("not connected! ");
                            LogPrint(msg);
                        }
                        if (!simulate)
                            Sleep(1000); // sleep 1 sec
                        return false;  // not connected to Server
                    }
                    else // isConnected
                    {
                        if (!optimize)
                            LogPrint(" is now connected!");
                    }
                }
                if (!s.isConnected)
                {
                    sessionEnded = true;
                    return false;
                }

                if (DetectChanged(ref s.isTradeAllowed, IsTradeAllowed()))
                {
                    if (!s.isTradeAllowed)
                    {
                        if (!optimize)
                            LogPrint(" EA not allowed to Trade !");
                        //closeAllTrades(reason: 7);
                        if (!simulate)
                            Sleep(1000); // sleep 1 sec
                        return false; // EA not allowed to Trade
                    }
                    else // isTradeAllowed
                    {
                        if (!optimize)
                            LogPrint(" is now IsTradeAllowed!");
                    }
                }
                if (!s.isTradeAllowed)
                {
                    sessionEnded = true;
                    return false;
                }

                if (DetectChanged(ref s.Stopped, IsEaStopped))
                {
                    if (s.Stopped)
                    {
                        if (!optimize)
                            LogPrint(" EA stopped !");
                        //closeAllTrades(reason: 8);
                        if (!simulate)
                            Sleep(1000); // sleep 1 sec
                        return false; // EA Stopped
                    }
                    else
                    {
                        if (!optimize)
                            LogPrint(" EA resumed !");
                    }
                }

                if (IsEaStopped)
                {
                    //closeAllTrades(reason: 9);
                    if (!simulate)
                        Sleep(1000); // sleep 1 sec
                    sessionEnded = true;
                    return false;
                }
            }
            return true; //OKToTrade
        }

        // Get latest Chart Bar
        internal BarData GetCurBar()
        {
            BarData dI = null;
            if (simulate)
            {
                dI = curBar;  // data from Simulator
                var b = new Bar();
                b.BarTime = dI.BarTime;
                b.Open = (decimal)dI.open;
                b.High = (decimal)dI.high;
                b.Low = (decimal)dI.low;
                b.Close = (decimal)dI.close;
                b.Volume = dI.volume;
                dI.bar = b;
                dI.ask = dI.close + 5 * point;
                dI.bid = dI.close - 5 * point;
                dI.spread = dI.ask - dI.bid;
            }
            else
            {
                int nBars = iBars(null, 0); // this symbol, this timeframe
                if (nBars <= 0)
                {
                    LogPrint("GetCurBar: iBars <= 0 !! iBars=" + nBars);
                    return dI;  // returns null
                }
                int last = Math.Max(1, 0);
                Bar b = ChartBars[last]; // last closed bar
                dI = new BarData(b, Bid, Ask);
                dI.bar = b;
            }
            return dI;
        }

        public double GetThePrice(int type, BarData b)
        {
            double price = -1;
            switch (type)
            {
                case (int)PriceTypes.PRICE_CLOSE:
                    price = b.close;
                    break;
                case (int)PriceTypes.PRICE_OPEN:
                    price = b.open;
                    break;
                case (int)PriceTypes.PRICE_HIGH:
                    price = b.high;
                    break;
                case (int)PriceTypes.PRICE_LOW:
                    price = b.low;
                    break;
                case (int)PriceTypes.PRICE_MEDIAN:
                    price = (b.high + b.low) / 2;
                    break;
                case (int)PriceTypes.PRICE_TYPICAL:
                    price = (b.high + b.low + b.close) / 3;
                    break;
                case (int)PriceTypes.PRICE_WEIGHTED:
                    price = (b.high + b.low + 2 * b.close) / 4;
                    break;
                case (int)PriceTypes.PRICE_OHLC:
                    price = Math.Round((b.open + b.high + b.low + b.close) / 4, 5);
                    break;
            }
            return price;
        }

        // Exit the specified Order at the specified price
        internal int ExitOpenTrade(int reason, Order order, double price = 0)
        {
            if (order == null)
                return -1;
            var orderID = (int)order.Id;
            var clsTime = GetOrderCloseTime(orderID);
            if (clsTime.DateTime.Year > 1970)
                return -1;  // already closed
            if (simulate && order.CloseDate == DateTime.MinValue)  // CloseDate not yet set
            {
                order.ClosePrice = (decimal)((price > 0) ? price : curPrice);
                order.CloseDate = curTime;
                order.CloseType = (reason == 50) ? CloseType.Market : CloseType.Unknown;
            }
            else if (!simulate)
            {
                var lots = (double)order.Quantity;
                if (lots > 0)
                {
                    if (!optimize)
                        LogPrint("Closd order=" + orderID.ToString() + " lots=" + lots.ToString());
                    if (OrderSelect(orderID, SELECT_BY_TICKET) == true)
                    {
                        if (!optimize)
                            LogPrint("Open price for order #" + orderID.ToString() + " is " + OrderOpenPrice().ToString());
                    }
                    else // OrderSelect returned err
                    {
                        var err = GetLastError();
                        if (!optimize)
                            LogPrint("ExitOpenTrade: ticket=" + orderID + "  !!! OrderSelect returned error of " + ErrorDescription(err));
                        return -1;
                    }
                    // !PendingNew then Open Order, use OrderClose
                    {
                        OrderClose(orderID, lots, 0, 0);
                        if (!simulate)
                            Sleep(500);
                    }
                }
                else    // lots <= 0
                {
                    order.ClosePrice = (decimal)((price > 0) ? price : curPrice);
                    order.CloseDate = curTime;
                }
            }
            if (order.CloseDate == DateTime.MinValue)  // CloseDate not yet set
            {
                order.CloseDate = GetOrderCloseTime(orderID);
            }
            s.stats.orderExits++; // count orderExits
            var dProfit = TradeClosed(order); // compute Order statistics
            dProfit = (double)((order.Profit == decimal.MinValue) ? 0 : order.Profit); // compute Order statistics
            if (!simulate)
            {
                LogPrint("closeOpenTrade orderID=" + orderID.ToString() + "  reason=" + reason.ToString()
                    + " price=" + order.ClosePrice.ToString("F5")
                    + " stoploss=" + order.StopLoss.ToString()
                    + "\n");
                LogPrint(" profitLoss=" + s.stats.profitLoss.ToString()
                    + " numWins=" + s.stats.numWins.ToString()
                    + " numLoss=" + s.stats.numLoss.ToString()
                    + " maxDrawdown=" + s.stats.maxDrawdown.ToString()
                    );
                JournalOnExit(reason, order, bclose: (double)s.dI.close, dI: s.dI, dProfit: dProfit);
            }
            if (!optimize)
            {
                string msg = ("ExitOpenTrade: order=" + orderID + " reason=" + reason + " qty=" + order.Quantity + " dProfit=" + dProfit + " balance=" + accountBalance);
                LogPrint(msg);
            }

            return orderID;
        }

        // Specified Order was Closed, compute statistics
        public double TradeClosed(Order order)
        {
            if (order == null)
                return 0;
            if (order.Type == TradeType.Stop)
                return 0;
            var orderID = (int)order.Id;
            double dProfit;
            dProfit = GetProfit(order);
            if (dProfit == double.MinValue)
                dProfit = 0;
            order.Profit = (decimal)dProfit;
            if (!simulate)
            {
                order.CloseDate = GetOrderCloseTime(orderID);
                order.ClosePrice = (decimal)GetOrderClosePrice(orderID, order);
            }
            if (!s.closedOrders.Keys.Contains(orderID))  // if orderID is not in closedOrders list
            {
                s.closedOrders.Add(orderID, order); // add Order to closedOrders list
                ComputeStats(dProfit, order); // compute statiustics
                if (!optimize)
                {
                    order.Comment +=  // add closing data to order.Comment
                        "," + order.CloseDate.ToString("ddd dd MMM yyyy HH:mm:ss")
                        + "," + order.ClosePrice.ToString("F5")
                        + "," + dProfit.ToString("F2");
                    LogPrint("TradeClosed: orderID=" + orderID
                        + " side=" + order.Side
                        + " price=" + order.ClosePrice.ToString("F5")
                        + " qty=" + order.Quantity.ToString("F2")
                        + " dProfit=" + dProfit.ToString("F5"));
                    if (firstLine)
                    {
                        WriteTradeLog("EA,symbol,tf,state,Id,side,qty,openDate,openPrice,StopLoss,TakeProfit,closeDate,closePrice,profit,closeType,balance", true);
                        firstLine = false;
                    }
                    WriteTradeLog(order.Comment + ", " + order.CloseType.ToString() + "," + simAccountBalance.ToString("F2")); // write traded data from order.Comment to TradeLog file
                }
            }
            return dProfit;
        }

        /// <summary>
        /// IsEAConnected: calls Alveo IsConnected()
        /// </summary>
        /// <returns>bool IsConnected</returns>
        bool IsEAConnected()
        {
            if (!simulate)
                return IsConnected();
            else
                return true;
        }

        // Close All trades for the specified reason and optionally clear buyOpenOrders and sellOpenOrders lists
        internal void closeAllTrades(int reason, bool clear = true, int sidemask = 0xF)
        {
            if (!optimize)
            {
                string msg = ("closeAllTrades: reason=" + reason + " curTime=" + curTime.ToShortDateString() + " " + curTime.ToLongTimeString());
                LogPrint(msg);
            }
            if (!simulate) // Alveo functions
            {
                int total = GetTotalOrders();
                Order order = null;
                for (int pos = 0; pos < total; pos++)
                {
                    if (OrderSelect(pos, SELECT_BY_POS) == false)
                        continue;
                    var cm = OrderComment();
                    if (!cm.Contains(magicStr))
                        continue;
                    var ticket = OrderTicket();  // get ticket (order.Id)
                    if (((sidemask & 0x1) > 0) && s.buyOpenOrders.ContainsKey(ticket))  // get Order data from buyOpenOrders list
                    {
                        order = s.buyOpenOrders[ticket];
                    }
                    else if (((sidemask & 0x2) > 0) && s.sellOpenOrders.ContainsKey(ticket)) // get Order data from sellOpenOrders list
                    {
                        order = s.sellOpenOrders[ticket];
                    }
                    else
                        continue;
                    ExitOpenTrade(reason, order, curPrice);  // Exit the specified Order for the specified reason at the curPrice
                }
            }
            else // simulate functions
            {
                if (((sidemask & 0x1) > 0) && s.buyOpenOrders.Count > 0)  // buyOpenOrders
                    foreach (var order in s.buyOpenOrders.Values)
                    {
                        ExitOpenTrade(reason, order, curPrice); // Exit the specified Order for the specified reason at the curPrice
                    }
                if (((sidemask & 0x2) > 0) && s.sellOpenOrders.Count > 0)  // buyOpenOrders
                    foreach (var order in s.sellOpenOrders.Values)
                    {
                        ExitOpenTrade(reason, order, curPrice); // Exit the specified Order for the specified reason at the curPrice
                    }
            }
            if (clear)
            {
                if ((sidemask & 0x1) > 0)
                    s.buyOpenOrders.Clear();
                if ((sidemask & 0x2) > 0)
                    s.sellOpenOrders.Clear();
            }
            if (!simulate)
                Sleep(1000); // sleep 1 sec
            return;
        }

        // if Time to Exit, then return true; otherwise false
        internal bool CheckTradingClosed()
        {
            bool closed = false;
            var tm = GetCurTime();
            var lt = GetLocalCurTime();
            closed = ((sessionIgnoreSunday && lt.DayOfWeek == System.DayOfWeek.Sunday)
                || tm.DayOfWeek == System.DayOfWeek.Saturday
                || (lt.DayOfWeek == System.DayOfWeek.Friday && lt.TimeOfDay > fridayclose)
                || (tm.DayOfWeek == System.DayOfWeek.Sunday && tm.TimeOfDay < sundayOpen)
                );
            return closed;
        }

        // convert Alveo int err to string errorDescription
        string ErrorDescription(int err)
        {
            string errorDescription = "err# " + err.ToString();
            switch (err)
            {
                case 0:
                    errorDescription += " ERR_NO_ERROR";
                    break;
                case 1:
                    errorDescription += " ERR_NO_RESULT";
                    break;
                case 2:
                    errorDescription += " ERR_COMMON_ERROR";
                    break;
                case 3:
                    errorDescription += " ERR_INVALID_TRADE_PARAMETERS";
                    break;
                case 4:
                    errorDescription += " ERR_SERVER_BUSY";
                    break;
                case 5:
                    errorDescription += " ERR_OLD_VERSION";
                    break;
                case 6:
                    errorDescription += " ERR_NO_CONNECTION";
                    break;
                case 7:
                    errorDescription += " ERR_NOT_ENOUGH_RIGHTS";
                    break;
                case 8:
                    errorDescription += " ERR_TOO_FREQUENT_REQUESTS";
                    break;
                case 9:
                    errorDescription += " ERR_MALFUNCTIONAL_TRADE";
                    break;
                case 64:
                    errorDescription += " ERR_ACCOUNT_DISABLED";
                    break;
                case 65:
                    errorDescription += " ERR_INVALID_ACCOUNT";
                    break;
                case 128:
                    errorDescription += " ERR_TRADE_TIMEOUT";
                    break;
                case 129:
                    errorDescription += " ERR_INVALID_PRICE";
                    break;
                case 130:
                    errorDescription += " ERR_INVALID_STOPS";
                    break;
                case 131:
                    errorDescription += " ERR_INVALID_TRADE_volume";
                    break;
                case 132:
                    errorDescription += " ERR_MARKET_closed";
                    break;
                case 133:
                    errorDescription += " ERR_TRADE_DISABLED";
                    break;
                case 134:
                    errorDescription += " ERR_NOT_ENOUGH_MONEY";
                    break;
                case 135:
                    errorDescription += " ERR_PRICE_CHANGED";
                    break;
                case 136:
                    errorDescription += " ERR_OFF_QUOTES";
                    break;
                case 137:
                    errorDescription += " ERR_BROKER_BUSY";
                    break;
                case 138:
                    errorDescription += " ERR_REQUOTE";
                    break;
                case 139:
                    errorDescription += " ERR_ORDER_LOCKED";
                    break;
                case 140:
                    errorDescription += " ERR_LONG_POSITIONS_ONLY_ALlowED";
                    break;
                case 141:
                    errorDescription += " ERR_TOO_MANY_REQUESTS";
                    break;
                case 145:
                    errorDescription += " ERR_TRADE_MODIFY_DENIED";
                    break;
                case 146:
                    errorDescription += " ERR_TRADE_CONTEXT_BUSY";
                    break;
                case 147:
                    errorDescription += " ERR_TRADE_EXPIRATION_DENIED";
                    break;
                case 148:
                    errorDescription += " ERR_TRADE_TOO_MANY_ORDERS";
                    break;
                case 149:
                    errorDescription += " ERR_TRADE_HEDGE_PROHIBITED";
                    break;
                case 150:
                    errorDescription += " ERR_TRADE_PROHIBITED_BY_FIFO";
                    break;
                case 4000:
                    errorDescription += " ERR_NO_MQLERROR";
                    break;
                case 4001:
                    errorDescription += " ERR_WRONG_FUNCTION_POINTER";
                    break;
                case 4002:
                    errorDescription += " ERR_ARRAY_INDEX_OUT_OF_RANGE";
                    break;
                case 4003:
                    errorDescription += " ERR_NO_MEMORY_FOR_CALL_STACK";
                    break;
                case 4013:
                    errorDescription += " ERR_ZERO_DIVIDE";
                    break;
                case 4014:
                    errorDescription += " ERR_UNKNOWN_COMMAND";
                    break;
                case 4015:
                    errorDescription += " ERR_WRONG_JUMP";
                    break;
                case 4016:
                    errorDescription += " ERR_NOT_INITIALIZED_ARRAY";
                    break;
                case 4017:
                    errorDescription += " ERR_DLL_CALLS_NOT_ALlowED";
                    break;
                case 4018:
                    errorDescription += " ERR_CANNOT_LOAD_LIBRARY";
                    break;
                case 4019:
                    errorDescription += " ERR_CANNOT_CALL_FUNCTION";
                    break;
                case 4020:
                    errorDescription += " ERR_EXTERNAL_CALLS_NOT_ALlowED";
                    break;
                case 4021:
                    errorDescription += " ERR_NO_MEMORY_FOR_RETURNED_STR";
                    break;
                case 4022:
                    errorDescription += " ERR_SYSTEM_BUSY";
                    break;
                case 4051:
                    errorDescription += " ERR_INVALID_FUNCTION_PARAMVALUE";
                    break;
                case 4062:
                    errorDescription += " ERR_STRING_PARAMETER_EXPECTED";
                    break;
                case 4063:
                    errorDescription += " ERR_INTEGER_PARAMETER_EXPECTED";
                    break;
                case 4064:
                    errorDescription += " ERR_DOUBLE_PARAMETER_EXPECTED";
                    break;
                case 4065:
                    errorDescription += " ERR_ARRAY_AS_PARAMETER_EXPECTED";
                    break;
                case 4066:
                    errorDescription += " ERR_HISTORY_WILL_UPDATED";
                    break;
                case 4067:
                    errorDescription += " ERR_TRADE_ERROR";
                    break;
                case 4105:
                    errorDescription += " ERR_NO_ORDER_SELECTED";
                    break;
                case 4106:
                    errorDescription += " ERR_UNKNOWN_SYMBOL";
                    break;
                case 4107:
                    errorDescription += " ERR_INVALID_PRICE_PARAM";
                    break;
                case 4108:
                    errorDescription += " ERR_INVALID_TICKET";
                    break;
                case 4109:
                    errorDescription += " ERR_TRADE_NOT_ALLOWED";
                    break;
                default:
                    errorDescription += " unknown_err_code " + err.ToString();
                    break;
            }
            return errorDescription;
        }

        // Get Total number of Open orders
        internal int GetTotalOrders()
        {
            int total = 0;
            try
            {
                if (!simulate) // Alveo
                {
                    total = 0;
                    //LogPrint("GetTotalOrders: count=" + (s.buyOpenOrders.Count + s.sellOpenOrders.Count));
                    s.buyOpenOrders.Clear();
                    s.sellOpenOrders.Clear();
                    int count = OrdersTotal();
                    if (count == 0)
                    {
                        return total;
                    }
                    for (int pos = 0; pos < count; pos++)
                    {
                        if (OrderSelect(pos, SELECT_BY_POS) == false)
                            continue;
                        string cm = OrderComment();
                        if (cm == null || cm.Length < 1)
                            continue;
                        if (!cm.Contains(magicStr))
                        {
                            var ticket = OrderTicket();
                            LogPrint("GetTotalOrders: order does not conatain magicStr. ticket=" + ticket + " magicStr=" + magicStr);
                            continue;
                        }
                        DateTime ctm = OrderCloseTime();
                        if (ctm.Year > 1980)
                            continue;                           // closed
                        var order = new Order();
                        order.Id = OrderTicket();
                        if (order.Id < 0)
                            continue;
                        order.Symbol = symbol;
                        order.Side = (TradeSide)OrderType();
                        order.Comment = OrderComment();
                        order.OpenPrice = (decimal)OrderOpenPrice();
                        order.StopLoss = (decimal)OrderStopLoss();
                        order.TakeProfit = (decimal)OrderTakeProfit();
                        order.OpenDate = OrderOpenTime();
                        order.CloseDate = ctm;
                        order.ClosePrice = 0;
                        order.Profit = (decimal)OrderProfit();
                        order.Quantity = (decimal)OrderLots();
                        order.Type = TradeType.Market;
                        order.CloseType = CloseType.Unknown;
                        switch (order.Side)
                        {
                            case TradeSide.Buy:
                                s.buyOpenOrders.Add(order.Id, order);
                                break;
                            case TradeSide.Sell:
                                s.sellOpenOrders.Add(order.Id, order);
                                break;
                            default:
                                continue;   // unknown
                        }
                        total++;
                    }
                }
                else // !simulate
                    total = s.buyOpenOrders.Count + s.sellOpenOrders.Count;
            }
            catch (Exception e)
            {
                LogPrint("GetTotalOrders Exception: " + e.Message);
                LogPrint("GetTotalOrders Exception: " + e.StackTrace);
            }
            return total;
        }

        internal double GetProfit(Order order)
        {
            double profit = 0;
            if (order.Quantity > 0)
            {
                double dPips = 0;
                int ticketID = (int)order.Id;
                if (!simulate)
                {
                    if (OrderSelect(ticketID, SELECT_BY_TICKET) == true)
                        profit = OrderProfit();
                    else
                        profit = 0;
                }
                else  // simulate
                {
                    var side = order.Side;
                    dPips = GetPriceDiff(order) * pipPos;
                    dPips *= (side == TradeSide.Buy) ? 1.0 : -1.0;
                    profit = (double)order.Quantity * dPips * 10;
                }
            }
            return profit;
        }

        // return OrderCloseTime if closed, else return datetime0
        internal datetime GetOrderCloseTime(int ticketID)
        {
            Order order = null;
            DateTime closeTime = DateTime.MinValue;
            if (!simulate)
            {
                if (OrderSelect(ticketID, SELECT_BY_TICKET, pool: MODE_HISTORY) == true)
                {
                    closeTime = OrderCloseTime();
                    if (!optimize && closeTime.Year > 1980)
                        LogPrint("GetOrderCloseTime: Closed. ticketID=" + ticketID + " closeTime=" + closeTime.ToString());
                }
                else
                    closeTime = datetime0;
            }
            else // simulate
            {
                try
                {
                    Dictionary<long, Order> openOrders = s.buyOpenOrders;
                    openOrders = openOrders.Concat(s.sellOpenOrders).ToDictionary(x => x.Key, x => x.Value);
                    if (openOrders.Count > 0)
                        if (openOrders.Keys.Contains(ticketID))
                            order = openOrders[ticketID];
                }
                catch (KeyNotFoundException) // order not in openOrders
                {
                    order = null;
                }
                if (order != null) // order found
                {
                    if (order.CloseDate > DateTime.MinValue)  // order.CloseDate not default value
                        closeTime = order.CloseDate;
                    else
                        closeTime = datetime0;  // not closed
                }
            }
            return closeTime;
        }

        internal double GetOrderClosePrice(int ticketID)
        {
            Order order = null;
            double closePrice = 0;
            if (!simulate)
            {
                if (OrderSelect(ticketID, SELECT_BY_TICKET, pool: MODE_HISTORY) == true)
                {
                    closePrice = OrderClosePrice();
                    if (!optimize && closePrice > 0)
                        LogPrint("GetOrderClosePrice: Closed. ticketID=" + ticketID + " closePrice=" + closePrice.ToString());
                }
                else
                    closePrice = 0;
            }
            else // simulate
            {
                try
                {
                    Dictionary<long, Order> openOrders = s.buyOpenOrders;
                    openOrders = openOrders.Concat(s.sellOpenOrders).ToDictionary(x => x.Key, x => x.Value);
                    if (openOrders.Count > 0)
                        if (openOrders.Keys.Contains(ticketID))
                            order = openOrders[ticketID];
                }
                catch (KeyNotFoundException) // order not in recentOrders
                {
                    order = null;
                }
                if (order != null) // order found
                {
                    if (order.ClosePrice > 0)
                        closePrice = (double)order.ClosePrice;
                    else
                        closePrice = curPrice;  // not closed
                }
            }
            return closePrice;
        }

        // return OrderClosePrice - OrderOpenPrice
        internal double GetPriceDiff(Order order)
        {
            double priceDiff = 0;
            if (!simulate) // Alveo functions
                priceDiff = OrderClosePrice() - OrderOpenPrice();
            else
                priceDiff = (double)(order.ClosePrice - order.OpenPrice);
            return priceDiff;
        }

        internal double GetBid()
        {
            var digits = GetDigits();
            double bid = 0;
            if (!simulate)
                bid = Bid;
            else
                bid = Math.Round(curPrice - 5 * point, digits);
            return bid;
        }

        internal double GetAsk()
        {
            var digits = GetDigits();
            double ask = 0;
            if (!simulate)
                ask = Ask;
            else
                ask = Math.Round(curPrice + 5 * point, digits);
            return ask;
        }

        // Open a new Market Order in the targetDir with orderSL and orderTP
        public int CreateOrder(double lotsize = 0.01, int stoploss = 0, int takeprofit = 0)
        {
            int cmd = (ea.s.targetDir == 1) ? OP_BUY : (ea.s.targetDir == -1) ? OP_SELL : -1;
            if (!optimize)
                LogPrint("CreateOrder: cmd=" + cmd);
            string tf = timeFrame.ToString();
            int ticket = TryCreateOrder(cmd, lotsize, stoploss: stoploss, takeprofit: takeprofit, comment: magicStr);
            if (!ea.optimize)
            {
                var total2 = ea.GetTotalOrders();
                ea.LogPrint("CreateOrder: total=" + total2 + " ticket=" + ticket);
            }
            return ticket;
        }

        // try to create order with the specified parameters
        public int TryCreateOrder(int cmd, double orderQty, double price = 0, double stoploss = 0, double takeprofit = 0, string comment = "", int magic = 0, int exprTimeMin = 0, color clr = null)
        {
            int ticket = SendOrder(cmd, orderQty, price: price, stoploss: stoploss, takeprofit: takeprofit, comment: comment);
            if (!ea.optimize)
            {
                var total2 = ea.GetTotalOrders();
                ea.LogPrint("TryCreateOrder: total=" + total2 + " ticket=" + ticket + " comment=" + comment);
            }
            if (ticket != 0)
            {
                s.ordersThisHour++;  // increment ordersThisHour count
                s.ordersThisDay++;
            }
            else if (!optimize)
            {
                string msg = "TryCreateOrder: SendOrder failed." + " Side=" + ((cmd == 0) ? "Buy" : "Sell");
                LogPrint(msg);
            }
            s.stats.numOrders++;  // increment numTrades count
            return ticket;
        }

        // Get Normalize Digits from Alveo
        internal int GetDigits()
        {
            if (!simulate)
                return Digits;  // Alveo function
            else if (symbol.EndsWith("JPY"))
                return 3;
            return 5;
        }

        // Send OrderSend request to Alveo
        internal int SendOrder(int cmd, double volume, double price = 0, int slippage = 5, double stoploss = 0, double takeprofit = 0, string comment = "")
        {
            Order order = null;
            int ticket = 0;
            if (!simulate)  // Alveo functions
            {
                int err = 0;
                int cnt = 0;
                if (volume > 0)
                {
                    while (ticket <= 0 && err != 4109 && err != 132 && err != 133)
                    {
                        order = FormulateOrder(cmd, volume, stoploss, takeprofit, price, comment);
                        ticket = OrderSend(order.Symbol, cmd, (double)order.Quantity, (double)order.Price, slippage,
                            (double)order.StopLoss, (double)order.TakeProfit, comment: comment);
                        if (ticket <= 0) // Alveo returned err
                        {
                            ticket = 0; // invalid
                            err = GetLastError();
                            LogPrint("SendOrder: OrderSend failed !!");
                            LogPrint("Try OrderSend: cmd=" + cmd
                                + " vol=" + order.Quantity
                                + " price=" + order.Price
                                + " slippage=" + slippage
                                + " stoploss=" + order.StopLoss
                                + " takeprofit=" + order.TakeProfit
                                + " comment=" + order.Comment
                                );
                            cnt++;
                            if (cnt > 10)  // try up to 10 times before Exception
                            {
                                string msg = "SendOrder: OrderSend failed !! err=" + err.ToString();
                                LogPrint(msg);
                            }
                        }
                        else    // success
                        {
                            order.Id = ticket;
                            string msg = "SendOrder: OrderSend success. ticket=" + order.Id;
                            LogPrint(msg);
                        }
                        Sleep(2000); // Sleep 2 sec between OrderSends
                    }
                }
            }
            else // simulate, Simulator, not Alveo
            {
                order = FormulateOrder(cmd, volume, stoploss, takeprofit, price, comment);
                ticket = ++ticketNum;  // update simulated ticketNum
                order.Id = ticket;
            }
            if (ticket != 0)  // ticket valid
            {
                if (cmd == OP_BUY)
                {
                    s.buyOpenOrders.Add(ticket, order);  // add to buyOpenOrders list
                }
                else if (cmd == OP_SELL)
                {
                    s.sellOpenOrders.Add(ticket, order);  // add to sellOpenOrders list
                }
                if (!optimize) // save Order data in order.Comment and LogPrint info
                {
                    var total = GetTotalOrders();
                    LogPrint("SendOrder: total=" + total);
                    string msg = String.Format(",{0},{1},{2},{3},{4},{5},{6}",
                        order.Id.ToString(),
                        order.Side.ToString(),
                        order.Quantity.ToString(),
                        order.OpenDate.ToString("ddd dd MMM yyyy HH:mm:ss"),
                        order.OpenPrice.ToString("F5"),
                        order.StopLoss.ToString("F5"),
                        order.TakeProfit.ToString("F5"));
                    order.Comment = ((comment.Length > 0) ? comment : magicStr + ", ") + msg;
                    LogPrint("SendOrder: Opened order=" + order.Id
                        + " cmd=" + cmd.ToString()
                        + " Side=" + order.Side.ToString()
                        + " OpenPrice=" + order.OpenPrice.ToString("F5")
                        + " vol=" + order.Quantity.ToString("F2")
                        + " StopLoss=" + order.StopLoss.ToString("F5")
                        + " TakeProfit=" + order.TakeProfit.ToString("F5")
                        + " buyOpenOrders=" + s.buyOpenOrders.Count
                        + " sellOpenOrders=" + s.sellOpenOrders.Count
                        + " recentOrders=" + s.sellOpenOrders.Count
                        );
                }
            }
            return ticket;  // unique ticket number
        }

        internal Order FormulateOrder(int cmd, double qty, double stoploss, double takeprofit, double price = 0, string comment = "")
        {
            Order order = new Order();
            double orderSL = 0;
            double orderTP = 0;
            double orderQty = qty;
            var digits = GetDigits();  // Normalize parameters to digits decimal places for Alveo function
            switch (cmd)
            {
                case OP_BUY:
                    price = (price > 0) ? price : GetAsk();
                    orderSL = (stoploss > 0) ? price - stoploss * point : 0;
                    orderTP = (takeprofit > 0) ? price + takeprofit * point : 0;
                    order.Side = TradeSide.Buy;
                    break;
                case OP_SELL:
                    price = (price > 0) ? price : GetBid();
                    orderSL = (stoploss > 0) ? price + stoploss * point : 0;
                    orderTP = (takeprofit > 0) ? price - takeprofit * point : 0;
                    order.Side = TradeSide.Sell;
                    break;
                default:
                    throw new Exception("FormulateOrder: unknow cmd. cmd=" + cmd.ToString());
            }
            price = NormalizeDouble(price, digits);
            orderSL = NormalizeDouble(orderSL, digits);
            orderTP = NormalizeDouble(orderTP, digits);
            if (pctLotSize > 0)
            {
                var startingBalance = Math.Max(s.startingBalance, 0.01);
                double dailyDrawDown = Math.Min(Math.Max(startingBalance - accountBalance, 0), startingBalance);
                double pctDailyDrawDown = 100.0 * dailyDrawDown / startingBalance;
                double maxRisk = Math.Max(Math.Min(1.90, 4.6 - pctDailyDrawDown), 0.01);
                double Maxlots = (StopLoss <= 0) ? 0.01
                    : Math.Max(Math.Truncate(ea.accountBalance * maxRisk / (TickValue * StopLoss / 10)) / 100, 0.1);
                orderQty = Math.Max(Math.Truncate((double)pctLotSize * Maxlots) / 100, 0.01);
            }
            if (maxLotLimit > 0)
                orderQty = Math.Min(orderQty, maxLotLimit);
            orderQty = Math.Max(orderQty, 0);
            orderQty = NormalizeDouble(qty, 2);
            order.Id = 0;
            order.Symbol = symbol;
            order.Price = (decimal)price;
            order.Quantity = (decimal)orderQty;
            order.StopLoss = (decimal)orderSL;
            order.TakeProfit = (decimal)orderTP;
            order.CloseDate = DateTime.MinValue;
            order.ClosePrice = 0;
            order.Profit = decimal.MinValue;
            order.ExpirationDate = null;
            order.OpenDate = GetCurTime();
            order.OpenPrice = (decimal)price;
            order.CloseType = CloseType.Unknown;
            order.Type = TradeType.Market;
            string cmnt = comment;
            if (comment.Length == 0)
                cmnt = strategy;
            order.Comment = cmnt;
            return order;
        }

        internal bool ModifyOrder(int ticket, double stoploss, ref Order order)
        {
            bool res = false;
            int err = 0;
            int cnt = 0;
            if (!simulate)  // Alveo functions
            {
                if (!OrderSelect(ticket, SELECT_BY_TICKET))
                    return false;
                DateTime dt = OrderCloseTime();
                if (dt.Year > 1970)
                    return false;  // already closed
                if (OrderStopLoss() - stoploss > 10 * point)
                {
                    while (!res && err != 4109 && err != 132 && err != 133)
                    {
                        var prc = OrderOpenPrice();
                        var sl = NormalizeDouble(stoploss, Digits);
                        var tp = OrderTakeProfit();
                        res = OrderModify(ticket, prc, sl, tp, 0);

                        if (!res) // Alveo returned err
                        {
                            err = GetLastError();
                            if (err == 4108)
                                LogPrint(" about line 2340 OrderSend failed !!");
                            cnt++;
                            if (cnt > 10)  // try up to 10 times before Exception
                                throw new Exception("SendOrder: OrderModify failed !! err=" + err.ToString());
                        }
                        else // res = true
                        {
                            if (!optimize)
                                LogPrint(" ModifyOrder: ticket=" + ticket + " stoploss=" + stoploss.ToString("F5"));
                        }
                        if (!simulate)
                            Sleep(200); // Sleep 0.2 sec between OrderModify
                    }
                }
                else  // no need to change stoploss
                    res = false;
            }
            else // simulate
            {
                double mult = (order.Side == TradeSide.Buy) ? 1 : -1;
                double diff = mult * (curPrice - (double)order.StopLoss);
                if (diff > (stoploss + 10) * point)
                {
                    var digits = GetDigits();
                    var orderSL = NormalizeDouble(curPrice - mult * stoploss * point, digits);
                    if (!optimize)
                    {
                        string msg = "ModifyOrder: Order=" + order.Id + " SL moved from " + order.StopLoss + " to " + orderSL;
                        diff = mult * (orderSL - (double)order.OpenPrice);
                        if (diff > 0)
                            msg += " Profitable!!";
                        LogPrint(msg);
                    }
                    order.StopLoss = (decimal)orderSL;
                }
            }
            return res;  // unique ticket number
        }

        // emulate Alveo Chart.TimeFrame
        internal TimeFrame GetTimeframe()
        {
            TimeFrame tf = TimeFrame.M5;
            if (!simulate)
                tf = Chart.TimeFrame;
            else
                tf = simTimeframe;
            return tf;
        }

        internal int GetOrderType(int orderID, ref Order order)
        {
            int type = -1;
            if (!simulate)
            {
                if (OrderSelect(orderID, SELECT_BY_TICKET) == true)
                {
                    type = OrderType();
                }
                else
                    if (!optimize) LogPrint("GetOrderType: OrderSelect() returned error - " + GetLastError());
            }
            else
            {
                return (int)order.Type;
            }
            return type;
        }

        internal double GetOrderClosePrice(int orderID, Order order)
        {
            double clsPrice = (double)order.ClosePrice;
            if (!simulate)
            {
                if (order.Quantity > 0) // !virtual order
                {
                    if (OrderSelect(orderID, SELECT_BY_TICKET) == true)
                    {
                        clsPrice = OrderClosePrice();
                    }
                    else
                        if (!optimize) LogPrint("GetOrderClosePrice: OrderSelect() returned error - " + GetLastError());
                }
            }
            return clsPrice;
        }

        internal double GetOrderOpenPrice(int orderID, Order order)
        {
            double openPrice = (double)order.OpenPrice;
            if (!simulate)
            {
                if (order.Quantity > 0)
                {
                    if (OrderSelect(orderID, SELECT_BY_TICKET) == true)
                    {
                        openPrice = OrderOpenPrice();
                    }
                    else
                        if (!optimize) LogPrint("GetOrderOpenPrice: OrderSelect() returned error - " + GetLastError());
                }
            }
            return openPrice;
        }

        internal double GetPoints()
        {
            double point = 0.00001;
            pipPos = symbol.EndsWith("JPY") ? 100 : 10000;
            if (!simulate)
            {
                point = Point;
            }
            else
            {
                point = 1 / pipPos / 10;
            }
            return point;
        }

        internal int GetAccountNumber()  // Get account number
        {
            int account = 0;                    // default value for simulation
            if (!simulate)                      // Alveo running
                account = AccountNumber();      // Alveo function
            return account;
        }

        internal int GetPeriod()
        {
            int period = 1;     // default
            if (!simulate)
                period = Period();
            else
                period = (int)simTimeframe;
            return period;
        }

        internal double GetTickValue()
        {
            double TickValue = 10.00;
            string[] seps = { "/" };
            string[] terms = ea.symbol.Split(seps, StringSplitOptions.RemoveEmptyEntries);
            if (terms.Count() != 2)
                throw new Exception("GetTickValue.Run: symbol is incorrrect format. symbol=" + ea.symbol);
            switch (terms[1].Trim())
            {
                case "USD":
                    TickValue = 10.00;
                    break;
                case "JPY":
                    TickValue = 8.9263;
                    break;
                case "NZD":
                    TickValue = 6.7501;
                    break;
                case "AUD":
                    TickValue = 7.1496;
                    break;
                case "CAD":
                    TickValue = 7.6763;
                    break;
                case "CHF":
                    TickValue = 10.344;
                    break;
                case "GBP":
                    TickValue = 13.0629;
                    break;
                default:
                    throw new Exception("GetTickValue.Run: symbol is Unknown. symbol=" + ea.symbol);
            }
            TickValue = Math.Max(TickValue, 0.01);
            return TickValue;
        }

        #endregion

        #region Swings Class
        internal class Swings
        {
            int Period;
            Queue<double> highQ;
            Queue<double> lowQ;
            public double swingHigh;
            public double swingLow;

            internal Swings(int period)
            {
                Period = period;
                highQ = new Queue<double>();
                lowQ = new Queue<double>();
            }

            internal void Calc(double thePrice)
            {
                highQ.Enqueue(thePrice);
                while (highQ.Count > Period)
                    highQ.Dequeue();
                swingHigh = highQ.Max();
                lowQ.Enqueue(thePrice);
                while (lowQ.Count > Period)
                    lowQ.Dequeue();
                swingLow = lowQ.Max();
            }
        }
        #endregion

        #region SMAobj Class
        internal class SMAobj
        {
            FastTrack ea;
            int Period;
            double Threshold;
            Queue<double> Q;
            internal bool isRrising;
            internal bool isFalling;
            internal int trendDir;
            internal int prevTrendDir;
            internal int prevState;
            internal bool trendChanged;
            internal bool stateChanged;
            internal double prevValue;
            internal double value;
            internal bool firstrun;
            DateTime prevTM;
            internal double thePrice;

            // SMAobj constructor
            internal SMAobj()
            {
                Period = 50;
                Threshold = 1 * 1e-6;
                Q = null;
                isRrising = false;
                isFalling = false;
                trendDir = 0;
                prevTrendDir = 0;
                prevState = 0;
                trendChanged = false;
                stateChanged = false;
                value = double.MinValue;
                prevValue = value;
                prevTM = DateTime.MinValue;
                thePrice = 0;
                ea = null;
            }

            // SMAobj constructor with input parameters
            internal SMAobj(ref FastTrack ea, int period, int threshold = 0) : this()   // do SMAobj() first
            {
                this.ea = ea;
                Period = period;
                Q = new Queue<double>();
                Threshold = (double)threshold * 1e-6;
                thePrice = 0;
                firstrun = true;
            }

            internal void Init(BarData b)  // Initialize Indicator
            {
                Q.Clear();
                value = double.MinValue;
                prevValue = value;
                isRrising = false;
                isFalling = false;
                trendDir = 0;
                prevState = 0;
                prevTrendDir = 0;
                trendChanged = false;
                stateChanged = false;
                firstrun = false;
                prevTM = b.BarTime;
            }

            internal double Calc(BarData b)  // Calculate Indicator values
            {
                if (Period < 1)
                    throw new Exception("SMA.Calc: period < 1, invalid !!");
                if (Threshold < 0)
                    throw new Exception("SMA.Calc: Threshold < 0, invalid !!");
                if (firstrun)
                {
                    Init(b);
                }
                if (false && !ea.simulate && prevTM.Year > 1980)
                {
                    var dur = b.BarTime.Subtract(prevTM);
                    if (dur > TimeSpan.FromSeconds(0) && dur > TimeSpan.FromMinutes((int)ea.timeFrame * 2))
                    {
                        ea.Print("SMA: must reload. dur=" + dur.ToString() + " tm=" + b.BarTime.ToString() + " prevTM=" + prevTM.ToString());
                        Init(b);
                        return value;
                    }
                }
                prevTM = b.BarTime;
                if (trendDir != 0)
                    prevTrendDir = trendDir;
                prevState = trendDir;
                thePrice = ea.GetThePrice((int)ea.PriceType, b);
                Q.Enqueue(thePrice);
                while (Q.Count > Period)
                    Q.Dequeue();
                prevValue = value;
                value = Q.Average();
                if (prevValue < 0)
                    prevValue = value;
                isRrising = ((value - prevValue) > Threshold && thePrice > prevValue);
                isFalling = ((prevValue - value) > Threshold && thePrice < prevValue);
                trendDir = isRrising ? 1 : (isFalling ? -1 : 0);
                trendChanged = (trendDir * prevTrendDir < 0);
                stateChanged = (trendDir != prevState);
                return value;
            }
        }
        #endregion

        internal class HSTO
        {
            internal class HEMAobj
            {
                EMAobj ema1;
                EMAobj ema2;
                EMAobj ema3;
                double Period;
                double Threshold;
                double sqrtPeriod;
                internal bool isRrising;
                internal bool isFalling;
                internal int trendDir;
                internal int prevTrendDir;
                internal int prevState;
                internal bool trendChanged;
                internal bool stateChanged;
                internal double HEMAval;
                internal bool firstrun;

                // HEMAobj constructor
                HEMAobj()
                {
                    Period = 12;
                    Threshold = 1 * 1e-6;
                    sqrtPeriod = 1;
                    isRrising = false;
                    isFalling = false;
                    trendDir = 0;
                    prevTrendDir = 0;
                    prevState = 0;
                    trendChanged = false;
                    stateChanged = false;
                    HEMAval = double.MinValue;
                }

                // HEMAobj constructor with input parameters
                internal HEMAobj(int period, int threshold = 0) : this()   // do HEMA() first
                {
                    Period = period;
                    Threshold = (double)threshold * 1e-6;
                    sqrtPeriod = Math.Sqrt(Period);
                    ema1 = new EMAobj(period, threshold);
                    ema2 = new EMAobj(period / 2, threshold);
                    ema3 = new EMAobj(sqrtPeriod, threshold);
                    firstrun = true;
                }

                internal void Init(double thePrice)  // Initialize Indicator
                {
                    ema1.Init(thePrice);
                    ema2.Init(thePrice);
                    ema3.Init(thePrice);
                    HEMAval = ema3.EMAval;
                    isRrising = false;
                    isFalling = false;
                    trendDir = 0;
                    prevState = 0;
                    prevTrendDir = 0;
                    trendChanged = false;
                    stateChanged = false;
                    firstrun = false;
                }

                internal double Calc(double thePrice)  // Calculate Indicator values
                {
                    // HEMA(n) = EMA(2 * EMA(n / 2) – EMA(n)), sqrt(n))
                    if (Period < 1)
                        throw new Exception("HEMAcalc: period < 1, invalid !!");
                    if (Threshold < 0)
                        throw new Exception("HEMAcalc: Threshold < 0, invalid !!");
                    if (firstrun)
                    {
                        Init(thePrice);
                    }
                    if (trendDir != 0)
                        prevTrendDir = trendDir;
                    prevState = trendDir;
                    ema1.Calc(thePrice);
                    ema2.Calc(thePrice);
                    double term3 = 2 * ema2.EMAval - ema1.EMAval;
                    HEMAval = ema3.Calc(term3);
                    isRrising = ema3.isRrising;
                    isFalling = ema3.isFalling;
                    trendDir = isRrising ? 1 : (isFalling ? -1 : 0);
                    trendChanged = (trendDir * prevTrendDir < 0);
                    stateChanged = (trendDir != prevState);
                    return HEMAval;
                }
            }

            internal class EMAobj
            {
                double Period;
                double Threshold;
                double prevEMA;
                internal double EMAval;
                internal bool isRrising;
                internal bool isFalling;
                internal int trendDir;
                internal int prevTrendDir;
                internal int prevState;
                internal bool trendChanged;
                internal bool stateChanged;
                internal double K;

                internal EMAobj()
                {
                    Period = 12;
                    Threshold = 1 * 1e-6;
                    isRrising = false;
                    isFalling = false;
                    trendDir = 0;
                    prevTrendDir = 0;
                    prevState = 0;
                    trendChanged = false;
                    stateChanged = false;
                    prevEMA = double.MinValue;
                    EMAval = double.MinValue;
                    K = 1.0;
                }

                internal EMAobj(double period, int threshold = 0) : this()
                {
                    Period = period;
                    Threshold = (double)threshold * 1e-6;
                    K = 2.0 / ((double)Period + 1.0);
                }

                internal void Init(double thePrice)
                {
                    isRrising = false;
                    isFalling = false;
                    trendDir = 0;
                    prevState = 0;
                    prevTrendDir = 0;
                    trendChanged = false;
                    stateChanged = false;
                    prevEMA = thePrice;
                    EMAval = thePrice;
                }

                internal double Calc(double thePrice)
                {
                    if (Period < 1)
                        throw new Exception("EMAobj: period < 1, invalid !!");
                    if (Threshold < 0)
                        throw new Exception("EMAobj: Threshold < 0, invalid !!");
                    if (prevEMA == double.MinValue)
                        prevEMA = thePrice;
                    //EMA = (Price[today] x K) + (EMA[prev] x (1 – K)); K = 2 / (N + 1)
                    EMAval = (thePrice * K) + prevEMA * (1 - K);
                    var diff = EMAval - prevEMA;
                    prevEMA = EMAval;
                    isRrising = (diff > Threshold);
                    isFalling = (diff < -Threshold);
                    if (trendDir != 0)
                        prevTrendDir = trendDir;
                    prevState = trendDir;
                    trendDir = isRrising ? 1 : (isFalling ? -1 : 0);
                    trendChanged = (trendDir * prevTrendDir < 0);
                    stateChanged = (trendDir != prevState);
                    return EMAval;
                }
            }

            FastTrack ea;
            HEMAobj emaLow;
            HEMAobj emaHigh;
            HEMAobj emaClose;
            Queue<double> LowestLowQ;
            Queue<double> HighestHighQ;

            internal int K_period;
            internal int D_period;
            internal double Threshold;

            internal double smoothedK;
            internal double smoothedD;
            double prevSmoothedK;
            double prevSmoothedD;

            internal bool STOdone;
            internal bool pctKfalling;
            internal bool pctKrising;
            internal bool pctDfalling;
            internal bool pctDrising;
            internal int prevDtrend;
            internal int Dtrend;
            int counter;

            internal HSTO()
            {
                emaLow = null;
                emaHigh = null;
                emaClose = null;
                LowestLowQ = new Queue<double>();
                HighestHighQ = new Queue<double>();
                K_period = 0;
                D_period = 0;
                Threshold = 0;
                InitVars();
            }

            internal void InitVars()
            {
                STOdone = false;
                pctKfalling = false;
                pctKrising = false;
                pctDfalling = false;
                pctDrising = false;
                smoothedK = -1;
                smoothedD = -1;
                prevSmoothedK = 0;
                prevSmoothedD = 0;
                Dtrend = 0;
                prevDtrend = Dtrend;
            }

            internal HSTO(ref FastTrack eaIn, int k_period, int d_period, int threshold) : this()
            {
                ea = eaIn;
                K_period = k_period;
                D_period = d_period;
                Threshold = (double)threshold * 1e-7;
                emaLow = new HEMAobj(k_period);
                emaHigh = new HEMAobj(k_period);
                emaClose = new HEMAobj(k_period);
            }

            internal void Init(Bar b)
            {
                ea.Print("STO Init.");
                InitVars();
                emaLow.Init((double)b.Low);
                emaHigh.Init((double)b.High);
                emaClose.Init((double)b.Close);
                LowestLowQ.Clear();
                HighestHighQ.Clear();
                counter = 0;
            }

            internal void Calc(Bar theBar)
            {
                //ea.Print(theBar.Close);
                // % K = (Current Close - Lowest Low)/ (Highest High - Lowest Low) *100
                // Full % K = Fast % K smoothed with X - period SMA
                // Full %D = X-period SMA of Full %K
                if (theBar == null)
                    throw new Exception("Stochastic.calc: theBar==null.");
                var d = (double)D_period;
                var alpha = 1 / (d + 1) + 1 / (2 * d);
                emaLow.Calc((double)theBar.Low);
                emaHigh.Calc((double)theBar.High);
                emaClose.Calc((double)theBar.Close);
                LowestLowQ.Enqueue((double)emaLow.HEMAval);
                while (LowestLowQ.Count > K_period)
                    LowestLowQ.Dequeue();
                var min = LowestLowQ.Min();
                HighestHighQ.Enqueue(emaHigh.HEMAval);
                while (HighestHighQ.Count > K_period)
                    HighestHighQ.Dequeue();
                var max = HighestHighQ.Max();
                var diff = max - min;
                var pctK = 50.0;
                if (diff > 0)
                    pctK = Math.Min(Math.Max(100 * (emaClose.HEMAval - min) / diff, 0), 100);
                if (smoothedK < 0)
                {
                    smoothedK = pctK;
                    smoothedD = pctK;
                }
                prevSmoothedK = smoothedK;
                prevSmoothedD = smoothedD;
                smoothedK += alpha * (pctK - smoothedK);
                smoothedD += alpha * (smoothedK - smoothedD);
                var diff1 = smoothedK - prevSmoothedK;
                var diff2 = smoothedD - prevSmoothedD;
                pctKrising = (diff1 > Threshold);
                pctKfalling = (diff1 < -Threshold);
                pctDrising = (diff2 > Threshold);
                pctDfalling = (diff2 < -Threshold);
                prevDtrend = Dtrend;
                Dtrend = (pctDrising) ? 1 : ((pctDfalling) ? -1 : 0);
                STOdone = (LowestLowQ.Count >= K_period);
                counter++;
            }
        }
    }
}